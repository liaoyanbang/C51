#ifndef __MAIN_H
#define __MAIN_H
#include "stdio.h"
#include "RTX51TNY.h"   //����ϵͳͷ�ļ�
#include "oled.h"
#include "usart.h"
#include "key.h"
#include "ADS1015.h"
#include "p8563.h"
#include "at24c02.h"

void delay_ms(unsigned char ms);

#endif

