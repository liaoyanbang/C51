#include <reg51.h> 
 
 
void delayMills(unsigned int ms) 
{	
    unsigned char i,j;
		for(j=ms; j>0; j--)	
			for(i=100;i>0;i--);	
}
 
void main(void)    
{    
    while(1)   
    {  
       P0 = 0xfe;    //P0.0��  1111 1110
       delayMills(1000); 
       P0 = 0xfd;    //P0.1��  1111 1101
       delayMills(1000);  
       P0 = 0xfb;    //P0.2��  1111 1011
       delayMills(1000);   
       P0 = 0xf7;    //P0.3��  1111 0111
       delayMills(1000); 
       P0 = 0xef;    //P0.4��  1110 1111
       delayMills(1000); 
       P0 = 0xdf;    //P0.5��  1101 1111
       delayMills(1000);  
       P0 = 0xbf;    //P0.6��  1011 1111
       delayMills(1000); 
       P0 = 0x7f;    //P0.7��  0111 1111
       delayMills(1000); 
 
    }
}
