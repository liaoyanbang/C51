#include "reg51.h"
sbit BUZZ=P0^0;
sbit LED=P0^1;
void delay(char z)
{
		unsigned char	j,i;
   for(i=z;i>0;i--)
      for(j=110;j>0;j--);
}
int main()
{
	LED=1;
	BUZZ=1;
	while(1)
	{
		BUZZ=~BUZZ;
		LED=~LED;
		delay(1000);
	}
}